from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment
from openpyxl import Workbook 

from openpyxl import load_workbook
import math
import os
from collections import defaultdict

import pandas as pd


def fmodel():
	a=filepathdatamodel
	model_rows=6
	model_columns=4
	wb = load_workbook(a,data_only = True)# 实例化
	ws = wb['一般管理人员'] 
	while True:
		if ws.cell(model_rows,1).value or ws.cell(5,model_columns).value:
			if ws.cell(model_rows,1).value:
				model_rows=model_rows+1
			if ws.cell(5,model_columns).value:
				model_columns=model_columns+1
		else :
			model_columns=model_columns-1
			model_rows=model_rows-1
			break

	ws = wb['一般管理人员 (2)'] 
	model_columns02=4
	while True:
		if ws.cell(5,model_columns02).value:
			model_columns02=model_columns02+1
		else :
			model_columns02=model_columns02-1
			break
	return model_rows,model_columns,model_columns02


def getsheet(x,y,z):
	a=filepathdatamodel
	
	wb = load_workbook(a,data_only = True)# 实例化
	# ws = wb['一般管理人员']
	wbget = Workbook()
	alignment=Alignment(horizontal='center',

	vertical='center')
	
	for sheetnum in range(1,x-5+1):
		wsget = wbget.create_sheet(str(sheetnum))

		ws = wb['一般管理人员']

		# wsget.merge_cells('A2:A3')
		# wsget.merge_cells('B2:B3')

		wsget.cell(2,2).value="打分人\n被考核人"
		wsget.cell(2,1).value="部门"
		wsget.cell(2,1).alignment = alignment
		wsget.cell(2,2).alignment = alignment
		for department in range(4,y+1):
			if ws.cell(4,department).value:
				wsget.cell(department,1).value=ws.cell(4,department).value
				wsget.cell(department,2).value=ws.cell(5,department).value
				d=ws.cell(4,department).value
			else :
				wsget.cell(department,1).value=d
				wsget.cell(department,2).value=ws.cell(5,department).value

		ws = wb['一般管理人员 (2)']
		for department in range(4,z+1):
			if ws.cell(4,department).value:
				wsget.cell(department+y-4+1,1).value=ws.cell(4,department).value
				wsget.cell(department+y-4+1,2).value=ws.cell(5,department).value
				d=ws.cell(4,department).value
			else :
				wsget.cell(department+y+1-4,1).value=d
				wsget.cell(department+y+1-4,2).value=ws.cell(5,department).value
	wsget.alignment = alignment
	wbget.remove(wbget['Sheet'])
	wbget.save(filepath)
def getdata (x,y,z):
	wbget = load_workbook(filepath,data_only = True)# 实例
	option=6
	alignment=Alignment(horizontal='center',
	vertical='center')
	
	for b in wbget.sheetnames:
		
		wsget = wbget[b] 
		listsheet = os.listdir(filepathdata)
		pnamenum=3
		print (listsheet) 

		for allpeople_sheet in listsheet:
			getdata_rows=4
			charnum=0
			data_columns=4
			for char in allpeople_sheet:
				if char == '+':
					print (allpeople_sheet[:charnum])
					pname=allpeople_sheet[:charnum]
					break
				charnum =charnum+1

			allpeople_sheet=filepathdata+'/'+allpeople_sheet
			wb = load_workbook(allpeople_sheet,data_only = True)# 实例化
			ws = wb['一般管理人员']  #对表格进行读取操作
			wsget.cell(2,pnamenum).value=pname

			for data_columns in range (4,y+1):
				wsget.cell(getdata_rows,pnamenum).value=ws.cell(option,data_columns).value
				getdata_rows=getdata_rows+1
			
			wb = load_workbook(allpeople_sheet,data_only = True)# 实例化

			ws = wb['一般管理人员 (2)']  #对表格进行读取操作
			for data_columns in range(4,z+1):
				wsget.cell(getdata_rows,pnamenum).value=ws.cell(option,data_columns).value
				getdata_rows=getdata_rows+1

			# print (a)
			print (allpeople_sheet)
			pnamenum=pnamenum+1
		option=option+1
		print (ws)
		# break 
	wbget.alignment = alignment
	wbget.save(filepath)
	# print (pnamenum,"0000000000000000000000000000000")
	print('行数：' + str(x), '\n', '列数：' + str(y), '列数：' + str(z))
	return pnamenum-3

def main(shnum,b,c):
	wbget = load_workbook(filepath,data_only = True)
	for sheetnamenow in wbget.sheetnames:
		grade=0
		wsget = wbget[sheetnamenow]
		alignment=Alignment(horizontal='center',

	vertical='center')
		# print (a)
		for sheetnumnow_rows in range(4,b-3+c-3+4):
			gradesum = 0
			for sheetnumnow_columns in range(3,3+shnum):
				grade=wsget.cell(sheetnumnow_rows,sheetnumnow_columns).value
				# print (grade,",,,,,,,,,,,,,,,,,,,,,,,,,,")
				gradesum=grade+gradesum
			wsget.cell(sheetnumnow_rows,shnum+3).value=round(gradesum,2)
			wsget.cell(sheetnumnow_rows,shnum+4).value=round(gradesum/shnum,2)
		wsget.cell(2,shnum+3).value="总分："
		wsget.cell(2,shnum+4).value="平均分："
	wbget.save(filepath)
def rank_kci():
	wbset = Workbook()
	wbget = load_workbook(filepath,data_only = True)# 实例化

	# ws = wb['1'] 
	sheets=wbget.sheetnames
	# ws.auto_filter.ref = "M2:M14"
	# ws.auto_filter.add_filter_column(B2:B14)
	# ws.auto_filter.add_sort_condition("M4:M14")
	for sheetnum in sheets:
		wsset = wbset.create_sheet(sheetnum)
	wbset.save(filepathfi_sheet)
	print (sheets)
	print ('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
	# aa.to_excel('chengjicheng.xlsx')
	# # 打开excel
	writer = pd.ExcelWriter(filepathfi_sheet)
	# #sheets是要写入的excel工作簿名称列表
	# writer = pd.ExcelWriter("成绩汇总表.xlsx")
	i=0
	for sheet in sheets:
		print (wbget.sheetnames[i])
		wsget = wbget[wbget.sheetnames[i]]

		wsget.delete_rows(1)
		wbget.save(filepath)
		df = pd.read_excel(filepath,sheet_name=sheet)
		# print (df)
		aa=df.sort_values(
		['平均分：'], # 参数 by 指定排序依据关键列
		ascending = [False] # 参数ascending 指定对应参数by的关键列采用的升降序
		)
		# print(aa)
		# print (".........................................")
		aa.to_excel(writer, sheet_name=sheet)
		# wsset.insert_rows(1)
		writer.save()


		# wsgetfi.insert_rows(1)#删除行
		# wsgetfi.delete_cols(1)#删除列

		i=i+1

	wbget.save(filepath)
	wbget = load_workbook(filepathfi_sheet,data_only = True)# 实例化

	for sheet in wbget.sheetnames:
		wsget = wbget[sheet]

		wsget.delete_cols(1)
	wbget.save(filepathfi_sheet)
	os.remove(filepath)
if __name__ == '__main__':
	filepathdatamodel='data/model/model.xlsx'  #模型所在目录
	filepath='shengcheng/一般管理人员.xlsx'  #临时文件不用管
	filepathdata="data/yiban"               # 取数据文件夹
	filepathfi_sheet='shengcheng/一般管理人员_kci.xlsx'#最终生成的文件名称
	a,b,c=fmodel()     #获取投票模型的行数，和列数
	getsheet(a,b,c)      #生成表格
	shnum=getdata(a,b,c)
	main(shnum,b,c)    #计算总分，平均分
	rank_kci()       #排序，删除临时文件







